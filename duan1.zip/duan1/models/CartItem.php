<?php 

function updateCartItem($cartID, $productID, $data) {
    try {
        $setParams = get_set_params($data);

        $sql = "UPDATE cart_items SET $setParams WHERE cart_id = :cart_id AND product_id = :product_id";
        
        $stmt = $GLOBALS['conn']->prepare($sql);

        foreach ($data as $fieldName => &$value) {
            $stmt->bindParam(":$fieldName", $value);
        }

        $stmt->bindParam(":cart_id", $cartID);
        $stmt->bindParam(":product_id", $productID);

        $stmt->execute();
    } catch (\Exception $e) {
        debug($e);
    }
}

function deleteCartItem($cartID, $productID) {
    try {
        $sql = "DELETE FROM cart_items WHERE cart_id = :cart_id AND product_id = :product_id";
        
        $stmt = $GLOBALS['conn']->prepare($sql);

        $stmt->bindParam(":cart_id", $cartID);
        $stmt->bindParam(":product_id", $productID);

        $stmt->execute();
    } catch (\Exception $e) {
        debug($e);
    }
}