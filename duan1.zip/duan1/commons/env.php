<?php 

// Khai báo các biến môi trường dùng Global
define('PATH_CONTROLLER',   __DIR__ . '/../controllers/');
define('PATH_MODEL',        __DIR__ . '/../models/');
define('PATH_VIEW',         __DIR__ . '/../views/');

define('PATH_UPLOAD',       __DIR__ . '/../');

define('BASE_URL',          'http://localhost/duan1/');

define('DB_HOST',           'localhost');
define('DB_PORT',           '3306');
define('DB_USERNAME',       'root');
define('DB_PASSWORD',       '');
define('DB_NAME',           'duan1');


