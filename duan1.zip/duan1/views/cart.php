<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

    <!-- Latest compiled and minified CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Latest compiled JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</head>

<body>
    <div class="container">
        <div class="row">
            <h1 class="mt-3 mb-3">Giỏ hàng</h1>

            <table class="table">

                <tr>
                    <th>Imgae</th>
                    <th>Tên</th>
                    <th>Gía (ưu tiên giá sale)</th>
                    <th>Số lượng</th>
                    <th>Xóa</th>
                </tr>

                <?php if (isset($_SESSION['cart'])) : ?>
                    <?php foreach ($_SESSION['cart'] as $productID => $item) : ?>
                        
                        <tr>
                            <td>
                                <img src="<?= BASE_URL . $item['img_thumbnail'] ?>" width="50px" alt="">
                            </td>
                            <td><?= $item['name'] ?></td>
                            <td><?= $item['price_sale'] ?: $item['price_regular'] ?></td>
                            <td>
                                <a href="<?= BASE_URL . '?act=cart-dec&productID=' . $item['id'] ?>" class="btn btn-danger">-</a>
                                <input type="text" width="50px" style="width: 50px;" disabled value="<?= $item['quantity'] ?>">
                                <a href="<?= BASE_URL . '?act=cart-inc&productID=' . $item['id'] ?>" class="btn btn-success">+</a>
                            </td>
                            <td>
                                <a href="<?= BASE_URL . '?act=cart-delete&productID=' . $item['id'] ?>" class="btn btn-danger">Xóa</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>

            </table>
        </div>
    </div>
</body>

</html>