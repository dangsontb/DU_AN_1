<?php

function cartAdd($productID)
{
    // B1. Lấy dữ liệu của Product theo $productID
    $product = showOne('products', $productID);

    // B2. Thêm vào cart
    $cart = showOneCart('carts', $_SESSION['user']['id']);

    if (empty($cart)) {
        $cartID = insert_get_last_id('carts', [
            'user_id' => $_SESSION['user']['id'],
        ]);
    } else {
        $cartID = $cart['id'];
    }

    $_SESSION['cartID'] = $cartID;

    // B3. Thêm vào session, dùng productID để làm key cho từng item cart
    if (!isset($_SESSION['cart'][$productID])) {
        // B2:
        $_SESSION['cart'][$productID] = $product + ['quantity' => 1]; // ~ array_merge

        // Thêm cart items
        insert('cart_items', [
            'cart_id' => $cartID,
            'product_id' => $productID,
            'quantity' => 1,
        ]);
    }

    // B4. Chuyển hướng về trang giỏ hàng
    header('Location: ' . BASE_URL . '?act=cart-list');
}

function cartList() {
    require_once PATH_VIEW . 'cart.php';
};

function cartInc($productID)  {
   
    if (isset($_SESSION['cart'][$productID])) {
         // Thay đổi số lượng trong Session
        $_SESSION['cart'][$productID]['quantity'] += 1;

        // Cập nhật trong DB
        updateCartItem($_SESSION['cartID'], $productID, [
            'quantity' => $_SESSION['cart'][$productID]['quantity']
        ]);
    }

    header('Location: ' . BASE_URL . '?act=cart-list');
}

function cartDec($productID)  {
    if (isset($_SESSION['cart'][$productID]) && $_SESSION['cart'][$productID]['quantity'] > 1) {
        // Thay đổi số lượng trong Session
       $_SESSION['cart'][$productID]['quantity'] -= 1;

       // Cập nhật trong DB
       updateCartItem($_SESSION['cartID'], $productID, [
           'quantity' => $_SESSION['cart'][$productID]['quantity']
       ]);
   }

   header('Location: ' . BASE_URL . '?act=cart-list');
}

function cartDelete($productID)  {
    if (isset($_SESSION['cart'][$productID])) {

        // Xóa trong Session
        unset($_SESSION['cart'][$productID]);

       // Xóa trong DB
       deleteCartItem($_SESSION['cartID'], $productID);
   }

   header('Location: ' . BASE_URL . '?act=cart-list');
}